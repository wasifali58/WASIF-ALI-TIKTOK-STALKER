const axios = require('axios');

// Multiple TikTok API Sources
const API_SOURCES = [
    {
        url: 'https://apis.prexzyvilla.site/stalk/ttstalk?user={username}',
        parse: (data) => {
            if (data && data.status && data.data) return data.data;
            if (data && data.result) return data.result;
            return null;
        }
    },
    {
        url: 'https://api.siputzx.my.id/api/stalk/tiktok?username={username}',
        parse: (data) => {
            if (data && data.status && data.data) return data.data;
            if (data && data.user) return data;
            return null;
        }
    },
    {
        url: 'https://api.alyachan.my.id/api/tiktok?username={username}',
        parse: (data) => {
            if (data && data.status && data.data) return data.data;
            if (data && data.result) return data.result;
            return null;
        }
    }
];

// Fetch from a single source with timeout
async function fetchFromSource(source, username) {
    try {
        const url = source.url.replace('{username}', encodeURIComponent(username));
        const response = await axios.get(url, { timeout: 12000 });
        
        if (response.status === 200 && response.data) {
            const parsedData = source.parse(response.data);
            if (parsedData) {
                return {
                    success: true,
                    data: parsedData,
                    source: url
                };
            }
        }
        return null;
    } catch (error) {
        console.error('Source failed:', error.message);
        return null;
    }
}

// Format the response consistently
function formatResponse(rawData) {
    const user = rawData.user || rawData || {};
    const stats = rawData.stats || user.stats || {};
    
    return {
        username: user.uniqueId || user.username || '-',
        nickname: user.nickname || user.name || '-',
        avatar: user.avatarLarger || user.avatarMedium || user.avatar || '',
        verified: user.verified || false,
        private: user.privateAccount || user.isPrivate || false,
        signature: user.signature || user.bio || '',
        
        stats: {
            followers: stats.followerCount || stats.followers || 0,
            following: stats.followingCount || stats.following || 0,
            videos: stats.videoCount || stats.videos || 0,
            likes: stats.heartCount || stats.diggCount || stats.likes || 0
        },
        
        details: {
            userId: user.id || '-',
            region: user.region || user.country || '-',
            language: user.language || '-',
            created: user.createTime ? new Date(user.createTime * 1000).toISOString() : null,
            commerce: user.commerceUserInfo?.commerceUser || false,
            downloadSetting: user.downloadSetting === 0 ? 'Allowed' : 'Disabled'
        },
        
        developer: "WASIF ALI",
        telegram: "@FREEHACKS95"
    };
}

// Main API Handler
module.exports = async (req, res) => {
    // CORS Headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    // Handle OPTIONS request
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }
    
    // Home route
    if (req.url === '/' || req.url === '') {
        return res.json({
            status: "active",
            message: "TikTok Stalker API",
            usage: "/api/tiktok?username=wasifali88",
            developer: "WASIF ALI",
            telegram: "@FREEHACKS95"
        });
    }
    
    // Get username from query
    const username = req.query.username;
    
    if (!username) {
        return res.status(400).json({
            success: false,
            error: "Username parameter is required",
            developer: "WASIF ALI",
            telegram: "@FREEHACKS95"
        });
    }
    
    // Clean username
    const cleanUsername = username.replace(/@/g, '').trim();
    
    // Try all sources in parallel
    const promises = API_SOURCES.map(source => fetchFromSource(source, cleanUsername));
    const results = await Promise.all(promises);
    
    // Find first successful result
    const successResult = results.find(r => r !== null);
    
    if (successResult) {
        const formattedData = formatResponse(successResult.data);
        return res.json({
            success: true,
            ...formattedData
        });
    }
    
    // All sources failed
    return res.status(404).json({
        success: false,
        error: "Profile not found or all sources failed",
        developer: "WASIF ALI",
        telegram: "@FREEHACKS95"
    });
};